#include <iostream>
#include <fstream>
#include <vector>
#include <thread>
#include <future>
#include <mutex>
#include <atomic>
#include <cstring>
#include <iomanip>
#include <array>
#include <cmath>

struct ZipStats {
    size_t file_size = 0;
    size_t zero_bytes = 0;
    size_t non_zero_bytes = 0;
};

std::mutex stats_mutex;

extern "C" void process_chunk_ffi(
    const unsigned char* data,
    size_t size,
    ZipStats* stats
) {
    size_t zeros = 0;
    size_t nonzeros = 0;

    for (size_t i = 0; i < size; ++i) {
        if (data[i] == 0) {
            ++zeros;
        } else {
            ++nonzeros;
        }
    }

    std::lock_guard<std::mutex> lock(stats_mutex);
    stats->zero_bytes += zeros;
    stats->non_zero_bytes += nonzeros;
}

double calculate_entropy_async(const std::vector<unsigned char>& data) {
    std::array<size_t, 256> freq{};
    for (unsigned char b : data) {
        freq[b]++;
    }

    double entropy = 0.0;
    const double size = static_cast<double>(data.size());

    for (size_t f : freq) {
        if (f == 0) continue;
        double p = f / size;
        entropy -= p * std::log2(p);
    }

    return entropy;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage:: zip_summary <input.zip> <output.txt>" << std::endl;
        return 1;
    }

    const char* input_path = argv[1];
    const char* output_path = argv[2];

    std::ifstream file(input_path, std::ios::binary | std::ios::ate);
    if (!file) {
        std::cerr << "Failed to open input file\n";
        return 1;
    }

    size_t size = file.tellg();
    file.seekg(0);

    std::vector<unsigned char> buffer(size);
    file.read(reinterpret_cast<char*>(buffer.data()), size);
    file.close();

    ZipStats stats;
    stats.file_size = size;

    auto entropy_future = std::async(
        std::launch::async,
        calculate_entropy_async,
        std::cref(buffer)
    );

    const size_t chunk_size = 64 * 1024;
    std::vector<std::thread> workers;

    for (size_t offset = 0; offset < size; offset += chunk_size) {
        size_t len = std::min(chunk_size, size - offset);

        workers.emplace_back([&, offset, len]() {
            process_chunk_ffi(buffer.data() + offset, len, &stats);
        });
    }

    for (auto& t : workers) {
        t.join();
    }

    double entropy = entropy_future.get();

    std::ofstream out(output_path);
    if (!out) {
        std::cerr << "Failed to open the output file\n";
        return 1;
    }

    out << "ZIP Summary\n";
    out << "===========\n";
    out << "File size (bytes): " << stats.file_size << "\n";
    out << "Zero bytes:        " << stats.zero_bytes << "\n";
    out << "Non-zero bytes:    " << stats.non_zero_bytes << "\n";
    out << std::fixed << std::setprecision(4);
    out << "Estimated entropy: " << entropy << " bits/byte\n";

    out.close();

    std::cout << "Summary written to " << output_path << "\n";
    return 0;
}